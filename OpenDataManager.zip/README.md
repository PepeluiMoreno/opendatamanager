# OpenDataManager

Meta‑proyecto para la gestión declarativa de resolvers y fetchers de datos oficiales.
